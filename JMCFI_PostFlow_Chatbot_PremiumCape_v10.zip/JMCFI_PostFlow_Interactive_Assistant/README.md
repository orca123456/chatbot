# JMCFI PostFlow Assistant

This package contains the compact floating mascot widget for the PostFlow website. Open `index.html` in a browser to use the chat, animated eyes, hover wave, flying drag motion and chat message transitions. There is no round launcher background.

## Add it to your Laravel website

1. Copy `assets`, `postflow-chatbot.css` and `postflow-chatbot.js` into `public/postflow-chatbot/`.
2. Put `postflow-chatbot.blade.php` in `resources/views/components/` (rename it to `postflow-assistant.blade.php`).
3. In the common page layout just before closing `</body>` add:

   ```blade
   @include('components.postflow-assistant')
   ```

4. In the `<head>` add:

   ```blade
   <link rel="stylesheet" href="{{ asset('postflow-chatbot/postflow-chatbot.css') }}">
   ```

5. Before `</body>` after the component add:

   ```blade
   <script src="{{ asset('postflow-chatbot/postflow-chatbot.js') }}" defer></script>
   ```

## Connect to an authenticated Laravel assistant

By default, the widget has **working built-in answers** for common PostFlow questions. It **does not access user accounts or their specific request status**. The built-in FAQ is intentionally conservative about this.

To use your live chat service, set `data-endpoint="/chatbot/message"` on the `.pf-assistant` div. The widget sends `POST` JSON with `{ "message": "...", "history": [...] }` using the logged-in session and CSRF token, and expects JSON with `reply` as a string. Use Laravel authentication, authorization, rate limiting, server-side validation and safe input handling. Only return user data the authenticated requester is allowed to see.

## Behavior

- Mascot is ~92 px wide on desktop and ~82 px on small screens; transparent background.
- Eyes blink occasionally without changing the JMC chest crest.
- Hover triggers a wave and `Hi! Need help?`.
- Click to open/close; drag from the mascot to move it around the viewport.
- Drag changes angle, animates arm and trailing cape ribbons, and eases on landing.
- Input animates outgoing send icon, shows a typing indicator, and adds replies.
- Escape closes the panel, Enter or Space on launcher opens it. Reduced-motion setting is supported.

The built-in answers cover Department Head → VPAA → IMC approval, request tracking, publishing, rejection, accounts and notifications.


Updated behavior: smaller floating chatbot, speech bubble text “Hi! How can I help you today?”, natural blinking while speaking, no drag glow, and drag animation uses flowing purple cape ribbons.

Refinement added: smoother cloth-like cape motion while dragging, plus a subtle animated mouth for a more realistic talking effect.

Latest refinement: visible mouth animation while speaking, and cape motion now reacts more directly to drag speed and direction for a more cloth-like feel.

**Fixed real-mouth talking:** `assets/bot-mouth-talking.webp` is an animated sprite taken directly from the mascot’s existing smile, at the correct visor coordinates. It replaces the old incorrectly positioned CSS shape. Hover/touch while the greeting is active to see the lips moving. No voice/sound playback is included.


Cape update: the real visible cape on the mascot is now separated as its own layer and animated directly during dragging, instead of using a fake ribbon or light effect.

Soft cape update: the real cape now moves slower and softer with clearer fabric motion. Talking animation now activates only while the cursor or touch is directly interacting with the chatbot.

Premium cape refinement: drag motion now uses a slower and more elegant wave curve so the real cape feels more premium, cloth-like, and clearly visible while moving.