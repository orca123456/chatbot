/* Interactive PostFlow assistant: accessible FAQ, optional Laravel endpoint and pointer-based drag. */
(() => {
 'use strict';
 const motionOk = !matchMedia('(prefers-reduced-motion: reduce)').matches;
 const escapeText = s => String(s||'').trim().slice(0,500);
 function init(root){
  if(root.dataset.pfReady) return;
  root.dataset.pfReady='1';
  const trigger=root.querySelector('[data-pf-launcher]');
  const panel=root.querySelector('[data-pf-panel]');
  const closer=root.querySelector('[data-pf-close]');
  const body=root.querySelector('[data-pf-messages]');
  const form=root.querySelector('[data-pf-form]');
  const input=root.querySelector('[data-pf-input]');
  const send=root.querySelector('[data-pf-send]');
  const status=root.querySelector('[data-pf-status]');
  const endpoint=root.dataset.endpoint || window.POSTFLOW_CHAT_ENDPOINT || '';
  const width=()=>root.offsetWidth, height=()=>root.offsetHeight;
  let press=null, active=false, busy=false, history=[], speakTimer=0, greetTimer=0;
  const limit=(v,lo,hi)=>Math.min(Math.max(v,lo),Math.max(lo,hi));
  const reduced=()=>!motionOk;
  function showGreeting(ms=0){
    root.classList.add('pf-active-greet');
    clearTimeout(greetTimer);
    if(ms>0){ greetTimer=setTimeout(()=>root.classList.remove('pf-active-greet'), ms); }
  }
  function hideGreeting(){ clearTimeout(greetTimer); root.classList.remove('pf-active-greet'); }
  function startSpeaking(ms=2200){
    root.classList.add('pf-speaking');
    clearTimeout(speakTimer);
    speakTimer=setTimeout(()=>root.classList.remove('pf-speaking'), ms);
  }
  function layout(){
   const r=root.getBoundingClientRect();
   const pw=Math.min(352,innerWidth-18);
   const minMargin=9;
   const left=limit(r.right-pw,minMargin,innerWidth-pw-minMargin);
   panel.style.left=(left-r.left)+'px';
   panel.style.right='auto';
   root.classList.toggle('pf-align-left',r.left<180);
   const roomAbove=r.top-minMargin-10;
   const roomBelow=innerHeight-r.bottom-minMargin-10;
   const below=roomBelow>roomAbove;
   root.classList.toggle('pf-below',below);
   panel.style.height=Math.max(185,Math.min(492,below?roomBelow:roomAbove))+'px';
  }
  function setPos(x,y){
   root.style.left=limit(x,7,innerWidth-width()-7)+'px';
   root.style.top=limit(y,6,innerHeight-height()-7)+'px';
   root.style.right='auto';root.style.bottom='auto';layout();
  }
  function placeInitially(){
   const x=innerWidth-width()-(innerWidth<600?14:24);
   const y=innerHeight-height()-(innerWidth<600?12:18);
   setPos(x,y);
  }
  placeInitially();
  window.addEventListener('resize',()=>{const r=root.getBoundingClientRect();setPos(r.left,r.top);},{passive:true});
  function wave(){if(reduced())return;root.classList.remove('pf-wave');void root.offsetWidth;root.classList.add('pf-wave');setTimeout(()=>root.classList.remove('pf-wave'),1180)}
  function open(next){
   active=next;root.classList.toggle('pf-open',next);
   trigger.setAttribute('aria-expanded',String(next));
   trigger.setAttribute('aria-label', next?'Close PostFlow assistant':'Open PostFlow assistant');
   panel.setAttribute('aria-hidden',String(!next));panel.inert=!next;
   layout();
   if(next){wave(); setTimeout(()=>input.focus({preventScroll:true}),100)}
   else trigger.focus({preventScroll:true});
  }
  panel.inert=true;

  trigger.addEventListener('mouseenter',()=>{showGreeting(); startSpeaking(); wave();});
  trigger.addEventListener('mouseleave',()=>{ if(!press) { hideGreeting(); root.classList.remove('pf-speaking'); } });
  trigger.addEventListener('focus',()=>{showGreeting(); startSpeaking();});
  trigger.addEventListener('blur',()=>{ if(!press) { hideGreeting(); root.classList.remove('pf-speaking'); } });
  trigger.addEventListener('touchstart',()=>{showGreeting(2200); startSpeaking(2200);},{passive:true});

  trigger.addEventListener('pointerdown',e=>{
   if(e.button!==0||press) return;
   const r=root.getBoundingClientRect();
   press={id:e.pointerId,sx:e.clientX,sy:e.clientY,x:r.left,y:r.top,moved:false,lx:e.clientX,ly:e.clientY,vx:0,vy:0};
   trigger.setPointerCapture(e.pointerId);
   startSpeaking(2600);
  });
  trigger.addEventListener('pointermove',e=>{
   if(!press||press.id!==e.pointerId) return;
   const dx=e.clientX-press.sx,dy=e.clientY-press.sy;
   if(!press.moved&&Math.hypot(dx,dy)>6){press.moved=true;root.classList.remove('pf-landing');root.classList.add('pf-flying');showGreeting(4000);startSpeaking(4000);}
   if(!press.moved) return;
   press.vx=e.clientX-press.lx;press.vy=e.clientY-press.ly;
   press.lx=e.clientX;press.ly=e.clientY;
   const speed=Math.min(Math.hypot(press.vx,press.vy),20);
   const angle=(Math.atan2(press.vy,press.vx)*180/Math.PI);
   const tilt=limit(press.vx*1.05,-14,14);
   root.style.setProperty('--pf-tilt',tilt+'deg');
   root.style.setProperty('--pf-cape-rot', limit((angle*0.06) + (press.vx*0.13),-9,9) + 'deg');
   root.style.setProperty('--pf-cape-shift', (-2.5 - speed*0.30) + 'px');
   root.style.setProperty('--pf-cape-stretch', (1 + Math.min(speed*0.009,0.16)).toFixed(3));
   root.style.setProperty('--pf-cape-lift', limit((-press.vy*0.10),-3.6,3.6) + 'px');
   setPos(press.x+dx,press.y+dy);
   e.preventDefault();
  });
  function finish(e){
   if(!press||press.id!==e.pointerId)return;
   const p=press;press=null;
   if(trigger.hasPointerCapture(e.pointerId))trigger.releasePointerCapture(e.pointerId);
   root.classList.remove('pf-flying');
   if(p.moved){
    const r=root.getBoundingClientRect();
    const boost=motionOk?2.4:0;
    setPos(r.left+p.vx*boost,r.top+p.vy*boost);
    root.classList.add('pf-landing');
    setTimeout(()=>{root.classList.remove('pf-landing');root.style.setProperty('--pf-tilt','0deg');root.style.setProperty('--pf-cape-rot','0deg');root.style.setProperty('--pf-cape-shift','-1px');root.style.setProperty('--pf-cape-stretch','1');root.style.setProperty('--pf-cape-lift','0px');},520);
    if(e.pointerType==='touch'){ showGreeting(1200); startSpeaking(1200); }
    else { root.classList.remove('pf-speaking'); hideGreeting(); }
   } else if(e.type!=='pointercancel') open(!active);
  }
  trigger.addEventListener('pointerup',finish);
  trigger.addEventListener('pointercancel',finish);
  trigger.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open(!active)}});
  trigger.addEventListener('click',e=>{if(e.detail!==0)e.preventDefault()});
  closer.addEventListener('click',()=>open(false));
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&active)open(false)});
  document.addEventListener('pointerdown',e=>{if(active&&!root.contains(e.target))open(false)});

  function bubble(message,kind){
   const b=document.createElement('div');
   b.className='pf-bubble pf-in'+(kind==='user'?' pf-user':'');
   b.textContent=message;
   body.append(b);body.scrollTop=body.scrollHeight;
   return b;
  }
  function typing(){
   const el=document.createElement('div');el.className='pf-bubble pf-typing';el.setAttribute('role','status');el.setAttribute('aria-label','Assistant is typing');
   el.innerHTML='<i></i><i></i><i></i>';
   body.append(el);body.scrollTop=body.scrollHeight;return el;
  }
  function localAnswer(q){
   const t=q.toLowerCase();
   if(/hello|hi|hey|good (morning|afternoon|evening)/.test(t))return 'Hello! 👋 I can help you with posting requests, approval steps, and publication updates. What would you like to know?';
   if(/approv|workflow|department head|vpaa|vice president|imc|who review/.test(t))return 'PostFlow requests go through three approval levels:\n1. Department Head\n2. Vice President for Academic Affairs (VPAA)\n3. Institutional Media Center (IMC)\nOnce IMC approves, the approved post can be published automatically to the selected platforms.';
   if(/track|status|request|pending/.test(t))return 'To check a request, open My Requests in PostFlow and select your submission. You can review its current status and approval history there.';
   if(/reject|decline|reason/.test(t))return 'If your request is rejected, check the request details and notification for the reviewer’s reason. Update the content based on their comments before submitting again.';
   if(/publish|platform|facebook|post|failed/.test(t))return 'A post is scheduled for automatic publishing after final IMC approval. If publication fails, check its status in PostFlow and contact the IMC or the system administrator if the issue continues.';
   if(/register|log in|login|account|password|sign in/.test(t))return 'Use your authorized JMCFI account to sign in. For account access or password concerns, contact your PostFlow administrator.';
   if(/email|notif|remind/.test(t))return 'PostFlow uses email notifications to inform requestors and approvers about important actions and status changes. Check your institutional email inbox for updates.';
   return 'I can help with PostFlow approvals, request tracking, publishing, and notifications. For a specific account or request, please check your dashboard or contact your PostFlow administrator.';
  }
  function pause(ms){return new Promise(resolve=>setTimeout(resolve,ms))}
  async function reply(q){
   if(!endpoint){await pause(650);return localAnswer(q)}
   const csrf=document.querySelector('meta[name="csrf-token"]')?.content || '';
   const ac=new AbortController();const timer=setTimeout(()=>ac.abort(),12000);
   try {
    const r=await fetch(endpoint,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','Accept':'application/json',...(csrf?{'X-CSRF-TOKEN':csrf}:{})},body:JSON.stringify({message:q,history:history.slice(-8)}),signal:ac.signal});
    if(!r.ok) throw new Error('Server returned '+r.status);
    const json=await r.json();
    return typeof json.reply==='string'?json.reply:(typeof json.message==='string'?json.message:'Sorry, I could not understand the response.');
   } finally{clearTimeout(timer)}
  }
  async function sendText(raw){
   const q=escapeText(raw);if(!q||busy)return;
   busy=true;input.value='';send.disabled=true;send.classList.remove('pf-sending');void send.offsetWidth;send.classList.add('pf-sending');
   status.textContent='Message sent. Assistant is typing.';
   body.querySelector('.pf-choices')?.remove();bubble(q,'user');history.push({role:'user',content:q});
   const indicator=typing();
   try {
    const response=await reply(q);
    indicator.remove();bubble(response,'bot');history.push({role:'assistant',content:response});status.textContent='Reply received.';
   } catch(err){
    indicator.remove();bubble('I’m having trouble connecting right now. Please try again or contact your PostFlow administrator.','bot');status.textContent='Unable to connect to assistant.';
   } finally{busy=false;send.disabled=false;setTimeout(()=>send.classList.remove('pf-sending'),500);input.focus({preventScroll:true})}
  }
  form.addEventListener('submit',e=>{e.preventDefault();sendText(input.value)});
  root.querySelectorAll('[data-pf-question]').forEach(b=>b.addEventListener('click',()=>sendText(b.dataset.pfQuestion||'')));
 }
 document.querySelectorAll('[data-postflow-assistant]').forEach(init);
})();
