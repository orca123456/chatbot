<!-- Floating JMCFI PostFlow assistant -->
<div class="pf-assistant" data-postflow-assistant data-endpoint="">
  <section class="pf-panel" data-pf-panel id="pf-assistant-dialog" role="dialog" aria-label="PostFlow Assistant" aria-hidden="true">
    <header class="pf-head">
      <img class="pf-avatar" src="{{ asset('postflow-chatbot/assets/bot-full.webp') }}" alt="" draggable="false">
      <div class="pf-heading"><h2>PostFlow Assistant</h2><p><span class="pf-online" aria-hidden="true"></span>Here to help</p></div>
      <button class="pf-close" type="button" data-pf-close aria-label="Close chat"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg></button>
    </header>
    <div class="pf-messages" data-pf-messages aria-live="polite" aria-relevant="additions">
      <div class="pf-day">PostFlow help</div>
      <div class="pf-bubble">Hi! How can I help you today?</div>
      <div class="pf-choices">
        <button type="button" data-pf-question="How does the approval process work?">Approval process</button>
        <button type="button" data-pf-question="How do I track my request?">Track a request</button>
        <button type="button" data-pf-question="What if publishing failed?">Publishing help</button>
      </div>
    </div>
    <form class="pf-form" data-pf-form>
      <label class="pf-sr" for="pf-chat-message">Type your message</label>
      <input class="pf-input" id="pf-chat-message" data-pf-input type="text" maxlength="500" placeholder="Ask me anything about PostFlow..." autocomplete="off" required>
      <button class="pf-send" data-pf-send type="submit" aria-label="Send message"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg></button>
    </form>
    <span class="pf-sr" data-pf-status role="status" aria-live="polite"></span>
  </section>
  <button class="pf-launcher" type="button" data-pf-launcher aria-label="Open PostFlow assistant" aria-expanded="false" aria-controls="pf-assistant-dialog" title="Drag to move, click to chat">
    <span class="pf-trail" aria-hidden="true"></span>
    <span class="pf-bot" aria-hidden="true">
      <img class="pf-sprite" src="{{ asset('postflow-chatbot/assets/bot-base.webp') }}" alt="" draggable="false">
      <img class="pf-sprite pf-eye-blink" src="{{ asset('postflow-chatbot/assets/bot-blink.webp') }}" alt="" draggable="false">
      <img class="pf-sprite pf-mouth-sprite" src="{{ asset('postflow-chatbot/assets/bot-mouth-talking.webp') }}" alt="" draggable="false">
      <img class="pf-sprite pf-wave-hand" src="{{ asset('postflow-chatbot/assets/bot-wave-hand.webp') }}" alt="" draggable="false">
    </span>
  </button>
  <span class="pf-greeting" aria-hidden="true">👋 Hi! How can I help you today?</span>
</div>
