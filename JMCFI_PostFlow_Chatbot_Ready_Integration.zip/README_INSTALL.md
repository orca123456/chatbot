# JMCFI PostFlow chatbot — Laravel integration

Copy the `public/postflow-chatbot` folder into your Laravel `public/` folder.
Copy `resources/views/components/postflow-chatbot.blade.php` into the same path in your project.

In your main Blade layout, just before `</body>`, add:

```blade
<link rel="stylesheet" href="{{ asset('postflow-chatbot/postflow-chatbot.css') }}">
<x-postflow-chatbot />
<script defer src="{{ asset('postflow-chatbot/postflow-chatbot.js') }}"></script>
```

The component is configured to POST to `/api/chatbot/message`. Verify the endpoint exists and that it accepts `{ "message": "...", "history": [] }`. The frontend expects JSON with a `reply` or `message` string. If your endpoint uses another format or authentication, adapt `reply()` in the JS and `data-endpoint` in the Blade component.

**Important:** This package is a Laravel Blade integration. If your visible website is rendered by React/Expo rather than Blade, do not paste the Blade tag into React. Mount the widget's HTML as a React component or embed it in a web container, and serve the CSS, JS and images from public assets. Confirm your CORS/auth setup before using a separate frontend origin.

The package includes the previous mascot assets, hover greeting, blinking/talking, draggable real-cape animation, and chat window. Test at your actual viewport sizes before deploying. No changes to your repository or production environment were made.
